
package modelo;

import java.io.Serializable;


public class Personaje implements Comparable<Personaje>, CSVSerializable, Serializable {
    
    // Atributos del personaje
    private int id;
    private String nombre;
    private ClasePersonaje clase;
    private int nivel;

    // Constructor clase personaje
    public Personaje(int id, String nombre, ClasePersonaje clase, int nivel) {
        this.id = id;
        this.nombre = nombre;
        this.clase = clase;
        this.nivel = nivel;
    }

    // Metodos getter y setter del personaje
    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public ClasePersonaje getClase() {
        return clase;
    }

    public int getNivel() {
        return nivel;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setClase(ClasePersonaje clase) {
        this.clase = clase;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }
    
    //Metodo para mostrar al personaje como un String
    @Override
    public String toString() {
        return "Id: " + id + ", Nombre: " + nombre + ", Clase: " + clase + ", Nivel: " + nivel + '}';
    }
    
    // Metodo de comparacion para ordenar a los personajes por nombre
    @Override
    public int compareTo(Personaje p) {
        return this.nombre.compareTo(p.nombre);
    }
    
    // Metodo para convertir al personaje de String a CSV (representación)
    @Override
    public String toCSV() {
        return id + "," + nombre + "," + clase + "," + nivel;
    }
  
    // Metodo estatico para crear un personaje a través de un archivo CSV
    public static Personaje fromCSV(String linea) {
        Personaje toReturn = null;
        String[] values = linea.split(",");
        if (values.length == 4) {
            int id = Integer.parseInt(values[0]);
            String nombre = values[1];
            ClasePersonaje clase = ClasePersonaje.valueOf(values[2]);
            int nivel = Integer.parseInt(values[3]);
            toReturn = new Personaje(id, nombre, clase, nivel);
        }
        return toReturn;
    }
    

}
