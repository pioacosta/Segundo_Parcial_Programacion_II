package modelo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class Inventario<T extends CSVSerializable> implements Iterable<T> {

    // Lista de elementos en el inventario
    private List<T> items = new ArrayList<>();

    // Agrega un elemento al inventario
    public void agregar(T item) {
        if (item == null) {
            throw new IllegalArgumentException("No admite Null");
        }
        items.add(item);
    }

    // Elimina un elemento del inventario en la posición que se le pase
    public void eliminar(int indice) {
        chequearRango(indice);
        items.remove(indice);
    }

    // Chequea que los indices estén dentro del rango de la lista de elementos
    private void chequearRango(int rango) {
        if (rango < 0 || rango >= items.size()) {
            throw new IndexOutOfBoundsException("Indice fuera de rango");
        }
    }

    // Filtra los elementos según un criterio
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> aux = new ArrayList<>();
        for (T item : items) {
            if (criterio.test(item)) {
                aux.add(item);
            }
        }
        return aux;
    }

    // Ordena los elementos del inventario por orden natural
    public void ordenar() {
        ordenar((Comparator<? super T>) Comparator.naturalOrder());
    }

    // Ordena los elementos del inventario usando un comparador
    public void ordenar(Comparator<? super T> comparador) {
        items.sort(comparador);
    }

    // Transforma los elementos del inventario aplicando una función
    public void transformar(Function<? super T, ? extends T> transformador) {
        List<T> transformados = new ArrayList<>();
        for (T item : items) {
            transformados.add(transformador.apply(item));
        }
        items = transformados;
    }

    // Guarda los elementos del inventario en un archivo binario
    public void guardarEnArchivo(String path) {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            salida.writeObject(items);

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    // Carga los elementos del inventario desde un archivo binario
    public void cargarDesdeArchivo(String path) {

        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            items = (List<T>) entrada.readObject();

        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }

    }

    // Guarda los elementos del inventario en un archivo CSV
    public void guardarEnCSV(String path) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            bw.write("id,nombre,clase,nivel\n");
            items.stream()
                    .filter(item -> item instanceof CSVSerializable)
                    .forEach(item -> {
                        try {
                            bw.write(((CSVSerializable) item).toCSV() + "\n");
                        } catch (IOException ex) {
                            System.out.println(ex.getMessage());
                        }
                    });
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    // Carga los elementos del inventario desde un archivo CSV
    public void cargarDesdeCSV(String path, Function<String, T> transformador) {

        items.clear();
        File archivo = new File(path);

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            br.readLine();
            while ((linea = br.readLine()) != null) {
                items.add(transformador.apply(linea));
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

    // Devuelve un iterador para los elementos del inventario
    @Override
    public Iterator<T> iterator() {
        if (!items.isEmpty() && items.get(0) instanceof Comparable) {
            return iterator((Comparator<? super T>) Comparator.naturalOrder());
        }
        return (new ArrayList<>(items)).iterator();
    }

    // Devuelve un iterador para los elementos del inventario según el comparador que se otorgue
    public Iterator<T> iterator(Comparator<? super T> comparador) {
        ArrayList<T> aux = new ArrayList<>(items);
        aux.sort(comparador);
        return aux.iterator();
    }

    // Realiza una acción sobre los elementos del inventario
    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T item : items) {
            accion.accept(item);
        }
    }

}
