package modelo;

@FunctionalInterface
public interface CSVSerializable{
    
    // Convierte objeto a CSV
    String toCSV();
}
