
package config;


public class AppConstants {
    
    public static final String PATH_FILES = "src/data/";
    public static final String PATH_CSV = PATH_FILES + "personajes.csv";
    public static final String PATH_SERIAL = PATH_FILES + "personajes.dat";

}
